<style>
    .panel-body{
        background-color: #FFBF00;

    }
    .panel-footer
    {
        background-color: #15eb27;
    }
    h5{
        font-style: bold;
    }
    </style>
<div style="clear:both" class="panel panel-default">
    <div class="panel-body">
      Panel content
    </div>
    <div class="panel-footer"><h5>Panel footer</h5></div>
  </div>
