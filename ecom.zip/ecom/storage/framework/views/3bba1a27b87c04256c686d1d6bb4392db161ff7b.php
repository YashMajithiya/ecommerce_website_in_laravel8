<?php $__env->startSection("content"); ?>
<style>
    h2{
        color: limegreen;

    }
    h5{
        color: aqua;
        font-style: bold;

    }
    h1{
        color: rgb(209, 89, 9);
        font-style: bold;
        align:left;
    }
    </style>
<div class="custom-product">
     <div class="col-sm-10">
        <div class="trending-wrapper">
            <h1>My orders </h1>
            <br>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class=" row searched-item cart-list-devider">
             <div class="col-sm-2">
                <a href="detail/<?php echo e($item->id); ?>">
                    <img class="trending-image" src="<?php echo e($item->gallery); ?>">
                  </a>
             </div>
             <div class="col-sm-4">
                    <div class="">
                      <h2>Name : <?php echo e($item->name); ?></h2>
                      <h5>Delivery Status : <?php echo e($item->status); ?></h5>
                      <h5>Address : <?php echo e($item->address); ?></h5>
                      <h5>Payment Status : <?php echo e($item->payment_status); ?></h5>
                      <h5>Payment Method : <?php echo e($item->payment_method); ?></h5>

                    </div>
             </div>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

     </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\ecom\resources\views/myorders.blade.php ENDPATH**/ ?>