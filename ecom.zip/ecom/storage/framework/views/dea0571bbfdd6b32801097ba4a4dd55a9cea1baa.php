<?php $__env->startSection("content"); ?>
<style>
body {
    margin: 0;
    padding: 0;
    font-family: Arial, Helvetica, sans-serif,bold;
    background-color: #034266;

}

h3 {
    color: #40E0D0;
}
h4{
    color: #FF00FF;

}
</style>

<div class="container">
   <div class="row">
       <div class="col-sm-6">
       <img class="detail-img" src="<?php echo e($product['gallery']); ?>" alt="">
       </div>
       <div class="col-sm-6">
           <a href="/"><button class="btn btn-warning "> Back </button></a>
       <h2><?php echo e($product['name']); ?></h2>
       <h2>Price : <?php echo e($product['price']); ?></h2>
       <h4>Details: <?php echo e($product['description']); ?></h4>
       <h4>category: <?php echo e($product['category']); ?></h4>
       <br><br>
       <form action="/add_to_cart" method="POST">
           <?php echo csrf_field(); ?>
           <input type="hidden" name="product_id" value=<?php echo e($product['id']); ?>>
       <button class="btn btn-danger">Add to Cart</button>
       </form>
       <br><br>
       <a href="/ordernow"><button class="btn btn-success">Buy Now</button>
       <br><br>
    </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\ecom\resources\views/detail.blade.php ENDPATH**/ ?>